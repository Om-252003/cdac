print("placeholder - we will replace this code")
def lambda_handler(event, context):
    return "OK"
