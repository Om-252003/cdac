package client;
import developer.Vehicle;

public class Demo {
	
	void perform(Vehicle v)
	{
		v.changeGear(2);
		v.speedUp(20);
		v.applyBrakes(0);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		Demo d = new Demo();
		d.perform(new TwoWheeler());
		d.perform(new FourWheeler());
	}

}
