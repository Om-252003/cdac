package client;

import developer.Vehicle;

public class FourWheeler implements Vehicle {
	public void changeGear(int a) {
	    System.out.println("FourWheeler gear changed to: " + a);
	}

	public void speedUp(int a) {
	    System.out.println("FourWheeler speed increased by: " + a + " km/h");
	}

	public void applyBrakes(int a) {
	    System.out.println("FourWheeler speed decreased by: " + a + " km/h");
	}

}
