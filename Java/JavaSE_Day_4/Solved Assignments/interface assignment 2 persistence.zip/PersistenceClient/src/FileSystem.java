import com.persistence.PersistenceMechanism;

public class FileSystem implements PersistenceMechanism {
    
    public void writeData(String ref) {
        System.out.println("Writing to FileSystem: " + ref);
    }

    
    public String readData() {
        return "Reading from FileSystem";
    }
}
