import com.persistence.PersistenceMechanism;

public class BigdataSystem implements PersistenceMechanism {
    
    public void writeData(String ref) {
        System.out.println("Writing to BigdataSystem: " + ref);
    }

    
    public String readData() {
        return "Reading from BigdataSystem";
    }
}
