import com.persistence.PersistenceMechanism;

public class Demo {
    public static void main(String[] args) {
        // Create array of PersistenceMechanism
        PersistenceMechanism[] mechanisms = {
            new FileSystem(),
            new DatabaseSystem(),
            new BigdataSystem()
        };

        // Traverse and only call BigdataSystem methods
        for (PersistenceMechanism pm : mechanisms) {
            if (pm instanceof BigdataSystem) {
                pm.writeData("Sample Big Data Entry");
                System.out.println(pm.readData());
            }
        }
    }
}
