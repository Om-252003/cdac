
import com.persistence.PersistenceMechanism;

public class DatabaseSystem implements PersistenceMechanism {
   
    public void writeData(String ref) {
        System.out.println("Writing to DatabaseSystem: " + ref);
    }

    
    public String readData() {
        return "Reading from DatabaseSystem";
    }
}
