package com.persistence;

public interface PersistenceMechanism {
    void writeData(String ref);
    String readData();
}

